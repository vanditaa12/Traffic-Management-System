/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package traffic.management.system;

import javax.swing.*;
import java.awt.*;
public class Logi extends JFrame{
    JTextField tfnum,tfnamee;
    JButton add,back;
    Logi(){
    setLayout(null);
    
    JLabel lblname = new JLabel("Name");
    lblname.setBounds(40,20,100,30);
    lblname.setFont(new Font("Raleway", Font.PLAIN,17));
    add(lblname);
    
    tfnamee = new JTextField();
    tfnamee.setBounds(150,20,150,30);
    add(tfnamee);
    
    JLabel lblnumber = new JLabel("Number");
    lblnumber.setBounds(40,70,100,30);
    lblnumber.setFont(new Font("Raleway", Font.PLAIN,17));
    add(lblnumber);
    
    tfnum = new JTextField();
    tfnum.setBounds(150,70,150,30);
    add(tfnum);
    
    ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/second.jpg"));
    Image i2 = i1.getImage().getScaledInstance(200,200, Image.SCALE_DEFAULT);
    ImageIcon i3 = new ImageIcon(i2);
    JLabel image = new JLabel(i3);
    image.setBounds(350,10,200,200);
    add(image);
        
    add = new JButton("Visit");
    add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add.setBounds(40,150,120,30);
//        add.addActionListener(this);
        add(add);
            
       
       back = new JButton("Cancel");
       back.setBackground(Color.BLACK);
       back.setForeground(Color.WHITE);
       back.setBounds(180,150,120,30);
//       back.addActionListener(this);
       add(back);
    setVisible(true);
    setBounds(50,50,750,800);
    }
        public static void main(String[] args){
        new Logi();
    }
}

