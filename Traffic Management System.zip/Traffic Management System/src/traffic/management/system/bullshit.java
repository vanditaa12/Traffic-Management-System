
package traffic.management.system;

import javax.swing.*;
import java.awt.*;

public class bullshit extends JFrame {
   bullshit(){
 setBounds(500,200,600,30);
        setVisible(true);
        setLayout(null);
getContentPane().setBackground(Color.WHITE);
   }
        public static void main(String[] args){
new bullshit();
}
}
