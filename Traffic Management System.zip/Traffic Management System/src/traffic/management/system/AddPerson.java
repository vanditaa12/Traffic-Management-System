package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddPerson extends JFrame implements ActionListener{
    
    JComboBox comboshift;
    JTextField tfname,tfnumber,tfdeg,tfplace;
    JRadioButton rmale,rfemale;
    JButton add,back;
    
    AddPerson(){
        
        
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel text = new JLabel("ADD PERSON FORM");
        text.setBounds(100,20,300,30);
        text.setFont(new Font("Raleway", Font.BOLD, 20));
        add(text);
        
        JLabel lblname = new JLabel("NAME");
        lblname.setBounds(35,100,200,20);
        lblname.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lblname);
        
        tfname = new JTextField();
        tfname.setBounds(200,100,200,20);
        add(tfname);
        
        JLabel lblcontact = new JLabel("CONTACT");
        lblcontact.setBounds(35,150,200,20);
        lblcontact.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lblcontact);
        
        tfnumber = new JTextField();
        tfnumber.setBounds(200,150,200,20);
        add(tfnumber);
        
        
        JLabel lblshift = new JLabel("SHIFT");
        lblshift.setBounds(35,200,200,20);
        lblshift.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lblshift);
        
        String options[] = {"Shift 1", "Shift 2", "Shift3"};
        comboshift = new JComboBox(options);
        comboshift.setBounds(200,200,200,25);
        add(comboshift);
        
        JLabel lbldeg = new JLabel("DESIGNATION");
        lbldeg.setBounds(35,250,200,20);
        lbldeg.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lbldeg);
        
        tfdeg = new JTextField();
        tfdeg.setBounds(200,250,200,20);
        add(tfdeg);
        
        JLabel lblgender = new JLabel("GENDER");
        lblgender.setBounds(35,300,200,20);
        lblgender.setFont(new Font("Raleway",Font.PLAIN,17));
        add(lblgender);
        
        rmale = new JRadioButton("Male");
        rmale.setBackground(Color.WHITE);
        rmale.setBounds(200,300,60,25);
        add(rmale);
        
        rfemale = new JRadioButton("Female");
        rfemale.setBackground(Color.WHITE);
        rfemale.setBounds(280,300,100,25);
        add(rfemale);
        
        ButtonGroup bg = new ButtonGroup();
       bg.add(rmale);
       bg.add(rfemale);
        
        JLabel lblplace = new JLabel("PLACE OF DUTY");
        lblplace.setBounds(35,350,200,20);
        lblplace.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lblplace);
        
        tfplace = new JTextField();
        tfplace.setBounds(200,350,200,20);
        add(tfplace);
        
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/twelve.jpg"));
       Image i2 = i1.getImage().getScaledInstance(250, 400, Image.SCALE_DEFAULT);
       ImageIcon i3 = new ImageIcon(i2);
       JLabel image = new JLabel(i3);
       image.setBounds(500,50,250,400);
       add(image);
        
       add = new JButton("Add");
       add.setBackground(Color.BLACK);
       add.setForeground(Color.WHITE);
       add.setBounds(100,410,120,25);
       add.addActionListener(this);
       add(add);
       
       back = new JButton("Back");
       back.setBackground(Color.BLACK);
       back.setForeground(Color.WHITE);
       back.setBounds(250,410,120,25);
       back.addActionListener(this);
       add(back);
       
        setBounds(350,350,800,550);
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == add){
        //JComboBox comboshift;
    String name = tfname.getText();
    String number = tfnumber.getText();
    String designation = tfdeg.getText();
    String place = tfplace.getText();
    
    String gender = null;
    //JRadioButton rmale,rfemale;
    //JButton add, back;
        if(rmale.isSelected()){
            gender="Male";
            
        } else if(rfemale.isSelected()){
            gender="Female";
        }
        String shift = (String) comboshift.getSelectedItem();
        
        if(name.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid name!");
        return;
        }
        if(number.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid number!");
        return;
        }
        if(designation.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a designation!");
        return;
        }
        if(place.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid place!");
        return;
        }
        
        try {
            Conn conn = new Conn();
            
            String query = "insert into addperson values('"+name+"','"+number+"','"+designation+"','"+place+"','"+gender+"','"+shift+"')";
            conn.s.executeUpdate(query);
            
            JOptionPane.showMessageDialog(null, "Information added Successfully!");
            setVisible(false);
            new Information();
        
        } catch(Exception e) {
            e.printStackTrace();
        }
        }
        else if(ae.getSource() == back){
            setVisible(false);
            new Information();
        }
        
    }
    
    public static void main(String[] args){
        new AddPerson();
    }
}


