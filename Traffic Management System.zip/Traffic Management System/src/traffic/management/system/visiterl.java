
package traffic.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class visiterl extends JFrame implements ActionListener{
    
    JTextField usert, passt;
    JButton login, cancel;
    
    visiterl(){
        getContentPane().setBackground(Color.WHITE);
        
        setLayout(null);
        
        JLabel userr = new JLabel("Name");
        userr.setBounds(40,20,100,30);
        add(userr);
        
        usert = new JTextField();
        usert.setBounds(150,20,150,30);
        add(usert);
        
        
        
        JLabel passw = new JLabel("Number");
        passw.setBounds(40,70,100,30);
        add(passw);
        
        passt = new JTextField();
        passt.setBounds(150,70,150,30);
        add(passt);
        
        login = new JButton("Visit");
        login.setBounds(40,150,120,30);
        login.setBackground(Color.BLACK);
        login.setForeground(Color.WHITE);
        login.addActionListener(this);
        add(login);
        
        cancel = new JButton("Cancel");
        cancel.setBounds(180,150,120,30);
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        add(cancel);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/second.jpg"));
        Image i2 = i1.getImage().getScaledInstance(200,200, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350,10,200,200);
        add(image);
        
        
        
        
    }
    
    public void actionPerformed(ActionEvent ae){
        if (ae.getSource() == login) {
       String user = usert.getText();
       String pass = passt.getText();
        
        try{
            Conn c = new Conn();
            
            String query = "insert into userlogin values('"+user+"','"+pass+"')";
            c.s.executeUpdate(query);
        
            
            
            
        } catch(Exception e){
            e.printStackTrace();
        }
        
    } 
        else if(ae.getSource() == cancel){
            setVisible(false);
            }
    }
    
    public static void main(String[] args){
        new visiterl();
    }
}