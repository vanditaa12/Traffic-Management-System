package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class log extends JFrame implements ActionListener{
    
    JTextField tfnum,tfnamee;
    JButton add,back;
    
    log(){
        
        setLayout(null);
        
        
        JLabel lblname = new JLabel("Name");
        lblname.setBounds(40,20,100,30);
        lblname.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lblname);
        
        tfnamee = new JTextField();
        tfnamee.setBounds(150,20,150,30);
        add(tfnamee);
        
        
        JLabel lblnumber = new JLabel("Number");
        lblnumber.setBounds(40,70,100,30);
        lblnumber.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lblnumber);
        
        tfnum = new JTextField();
        tfnum.setBounds(150,70,150,30);
        add(tfnum);
        
        
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/second.jpg"));
        Image i2 = i1.getImage().getScaledInstance(200,200, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350,10,200,200);
        add(image);
        
       add = new JButton("Visit");
       add.setBackground(Color.BLACK);
       add.setForeground(Color.WHITE);
       add.setBounds(40,150,120,30);
       add.addActionListener(this);
       add(add);
       
       back = new JButton("Cancel");
       back.setBackground(Color.BLACK);
       back.setForeground(Color.WHITE);
       back.setBounds(180,150,120,30);
       back.addActionListener(this);
       add(back);
       
        setBounds(500,200,600,290);
        setVisible(true);
        getContentPane().setBackground(Color.WHITE);
    }
    
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == add){
        //JComboBox comboshift;JTextField tfiname,tfdname,tfdeg,tfplace,tfcarn;
    //String carname = tfiname.getText();
    String username = tfnamee.getText();
    String number = tfnum.getText();
    
    
    
        
        
        if(username.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid name!");
        return;
        }
        
        
        try{
            Conn conn = new Conn();
            
            String query = "insert into userlogin values('"+username+"','"+number+"')";
            conn.s.executeUpdate(query);
            
            JOptionPane.showMessageDialog(null, "Information added Successfully!");
            setVisible(false);
            new Dasboard2();
        
        } catch(Exception e) {
            e.printStackTrace();
        }
        }
        else if(ae.getSource() == back){
            setVisible(false);
            new home();
        }
        
        }
    
    
    public static void main(String[] args){
        new log();
    }
}
