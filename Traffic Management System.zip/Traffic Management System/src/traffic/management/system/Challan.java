package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Challan extends JFrame implements ActionListener{
     
    JTextField tfname, tfphone, tfvehicle, tfreceipt, tfamount;
    JRadioButton rbonline, rbcash;
    JButton submit;
    JComboBox cbvtype;
    
    Challan(){
        setLayout(null);
        
        JLabel heading = new JLabel("CHALLAN DETAILS");
        heading.setFont(new Font("Tahoma", Font.BOLD, 20));
        heading.setBounds(150,20,200,20);
        add(heading);
        
        JLabel lblname = new JLabel("NAME");
        lblname.setBounds(20,65,120,30);
        lblname.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblname.setForeground(Color.BLACK);
        add(lblname);
        
       tfname = new JTextField();
       tfname.setBounds(300,65,150,30);
       add(tfname);
       
       JLabel lblphone = new JLabel("PHONE NO.");
        lblphone.setBounds(20,115,120,30);
        lblphone.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblphone.setForeground(Color.BLACK);
        add(lblphone);
        
       tfphone = new JTextField();
       tfphone.setBounds(300,115,150,30);
       add(tfphone);
        
        JLabel lblvehicle = new JLabel("VEHICLE NUMBER");
        lblvehicle.setBounds(20,165,300,30);
        lblvehicle.setFont(new Font("Tahoma", Font.PLAIN, 19));
        add(lblvehicle);
        
       tfvehicle = new JTextField();
       tfvehicle.setBounds(300,165,150,30);
       add(tfvehicle);
        
       JLabel lbltype = new JLabel("VEHICLE TYPE");
       lbltype.setBounds(20,215,300,30);
       lbltype.setFont(new Font("Tahoma", Font.PLAIN, 19));
       add(lbltype);
       
       String str[] = { "Bike", "Scooty", "Car", "Auto Rickshaw", "E Rickshaw", "Van", "Porter Rickshaw", "Bus", "Truck" };
       cbvtype = new JComboBox(str);
       cbvtype.setBounds(300,215,150,30);
       cbvtype.setBackground(Color.WHITE);
       add(cbvtype);
       
       
        JLabel lblreceipt = new JLabel("RECEIPT NUMBER");
        lblreceipt.setBounds(20,265,300,30);
        lblreceipt.setFont(new Font("Tahoma", Font.PLAIN, 19));
        add(lblreceipt);
        
       tfreceipt = new JTextField();
       tfreceipt.setBounds(300,265,150,30);
       add(tfreceipt);
       
        JLabel lblamount = new JLabel("AMOUNT");
        lblamount.setBounds(20,315,120,30);
        lblamount.setFont(new Font("Tahoma", Font.PLAIN, 19));
        add(lblamount);
        
       tfamount = new JTextField();
       tfamount.setBounds(300,315,150,30);
       add(tfamount);
       
        JLabel lblpay = new JLabel("PAYMENT");
        lblpay.setBounds(20,365,120,30);
        lblpay.setFont(new Font("Tahoma", Font.PLAIN, 19));
        add(lblpay);
        
       rbonline = new JRadioButton("Online");
       rbonline.setBounds(300,365,80,30);
       rbonline.setFont(new Font("Tahoma", Font.PLAIN, 12));
       rbonline.setBackground(Color.WHITE);
       add(rbonline);
       
       rbcash = new JRadioButton("Cash");
       rbcash.setBounds(385,365,80,30);
       rbcash.setFont(new Font("Tahoma", Font.PLAIN, 12));
       rbcash.setBackground(Color.WHITE);
       add(rbcash);
       
       ButtonGroup bg = new ButtonGroup();
       bg.add(rbonline);
       bg.add(rbcash);
       
       submit = new JButton("SUBMIT");
       submit.setBackground(Color.BLACK);
       submit.setForeground(Color.WHITE);
       submit.setBounds(200,435,150,30);
       submit.addActionListener(this);
       add(submit);
       
       
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/third.jpg"));
       Image i2 = i1.getImage().getScaledInstance(250, 400, Image.SCALE_DEFAULT);
       ImageIcon i3 = new ImageIcon(i2);
       JLabel image = new JLabel(i3);
       image.setBounds(500,50,250,400);
       add(image);
               
        getContentPane().setBackground(Color.WHITE);
        setBounds(600,500,850,540);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        String name = tfname.getText();
        String phone = tfphone.getText();
        String vehicle = tfvehicle.getText();
        String receipt = tfreceipt.getText();
        String amount = tfamount.getText();
        
        String pay = null;
        
        if(name.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid name!");
        return;
        }
        
        if(phone.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid cell number!");
        return;
        }
        
        if(vehicle.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a vehicle number!");
        return;
        }
        
        if(receipt.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a receipt number!");
        return;
        }
        
        if(amount.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid amount!");
        return;
        }
       
        
        if(rbonline.isSelected()){
            pay="Online";
            
        } else if(rbcash.isSelected()){
            pay="Cash";
        }
        String vtype = (String) cbvtype.getSelectedItem();
        
        
        try {
            Conn conn = new Conn();
            
            String query = "insert into tpolicec values('"+name+"','"+phone+"','"+vehicle+"','"+vtype+"','"+receipt+"','"+amount+"','"+pay+"')";
            conn.s.executeUpdate(query);
            
            JOptionPane.showMessageDialog(null, "Challan added Successfully!");
            setVisible(false);
        
        } catch(Exception e) {
            e.printStackTrace();
        }
        
    }
    
    public static void main(String[] args){
        new Challan();
    }
}
