package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Vehicle extends JFrame implements ActionListener{
    
    JComboBox comboshift;
    JTextField tfiname,tfdname,tfdeg,tfcarn;
    JButton add,back;
    
    Vehicle(){
        
        
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel text = new JLabel("POLICE VEHICLES");
        text.setBounds(100,20,300,30);
        text.setFont(new Font("Raleway", Font.BOLD, 20));
        add(text);
        
        JLabel lblmodel = new JLabel("CAR MODEL");
        lblmodel.setBounds(35,100,200,20);
        lblmodel.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lblmodel);
        
        String options[] = {"Maruti Ertiga", "Chevrolet Tavera", "Reva","Tata Indigo","Tata Sumo","Mahindra Bolero","Ford EcoSport","Mahindra TUV300","Toyota Innova","Tata Sumo","Tata Safari Strome"};
        comboshift = new JComboBox(options);
        comboshift.setBounds(250,100,200,25);
        add(comboshift);
        
        
        
        JLabel lbldriver = new JLabel("DRIVER");
        lbldriver.setBounds(35,150,200,20);
        lbldriver.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lbldriver);
        
        tfdname = new JTextField();
        tfdname.setBounds(250,150,200,20);
        add(tfdname);
        
        
        JLabel lblshift = new JLabel("INSPECTOR INCHARGE");
        lblshift.setBounds(35,200,200,20);
        lblshift.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lblshift);
        
        tfiname = new JTextField();
        tfiname.setBounds(250,200,200,20);
        add(tfiname);
        
        JLabel lbldeg = new JLabel("ALLOTTED TO");
        lbldeg.setBounds(35,250,200,20);
        lbldeg.setFont(new Font("Raleway", Font.PLAIN,17));
        add(lbldeg);
        
        tfdeg = new JTextField();
        tfdeg.setBounds(250,250,200,20);
        add(tfdeg);
        
        JLabel lblcnumber = new JLabel("CAR NUMBER");
        lblcnumber.setBounds(35,300,200,20);
        lblcnumber.setFont(new Font("Raleway",Font.PLAIN,17));
        add(lblcnumber);
        
        tfcarn = new JTextField();
        tfcarn.setBounds(250,300,200,20);
        add(tfcarn);
        
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/eighteen.jpg"));
       Image i2 = i1.getImage().getScaledInstance(250, 400, Image.SCALE_DEFAULT);
       ImageIcon i3 = new ImageIcon(i2);
       JLabel image = new JLabel(i3);
       image.setBounds(500,50,250,400);
       add(image);
        
       add = new JButton("Add");
       add.setBackground(Color.BLACK);
       add.setForeground(Color.WHITE);
       add.setBounds(100,410,120,25);
       add.addActionListener(this);
       add(add);
       
       back = new JButton("Back");
       back.setBackground(Color.BLACK);
       back.setForeground(Color.WHITE);
       back.setBounds(250,410,120,25);
       back.addActionListener(this);
       add(back);
       
        setBounds(350,350,800,550);
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == add){
        //JComboBox comboshift;JTextField tfiname,tfdname,tfdeg,tfplace,tfcarn;
    //String carname = tfiname.getText();
    String drivername = tfdname.getText();
    String allotedto = tfdeg.getText();
    String inspectorn = tfiname.getText();
    String carnumber = tfcarn.getText();
    
    
        String shift = (String) comboshift.getSelectedItem();
        
        if(drivername.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid name!");
        return;
        }
        if(inspectorn.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid number!");
        return;
        }
        if(carnumber.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a designation!");
        return;
        }
        if(allotedto.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid place!");
        return;
        }
        
        try {
            Conn conn = new Conn();
            //drivername = tfdname.getText();
    //String allotedto = tfdeg.getText();
    //String inspectorn = tfiname.getText();
    //String carnumber = tfcarn.getText();
            String query = "insert into addpolicevehicles values('"+shift+"','"+drivername+"','"+inspectorn+"','"+allotedto+"','"+carnumber+"')";
            conn.s.executeUpdate(query);
            
            JOptionPane.showMessageDialog(null, "Information added Successfully!");
            setVisible(false);
            new Information();
        
        } catch(Exception e) {
            e.printStackTrace();
        }
        }
        else if(ae.getSource() == back){
            setVisible(false);
            new Information();
        }
        
    }
    
    public static void main(String[] args){
        new Vehicle();
    }
}

