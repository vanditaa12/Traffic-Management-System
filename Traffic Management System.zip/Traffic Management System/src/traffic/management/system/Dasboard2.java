package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Dasboard2 extends JFrame implements ActionListener{
    
    Dasboard2(){
        setBounds(0,0,1550,1000);
        
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/trafficmanagement-926x360.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1550,1000, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,1550,1000);
        add(image);
        
        JLabel text = new JLabel("TRAFFIC MANAGEMENT SYSTEM");
        text.setBounds(400,80,1000,70);
        text.setFont(new Font("Tahoma",Font.PLAIN,46));
        text.setForeground(Color.WHITE);
        image.add(text);
        
        JMenuBar mb = new JMenuBar();
        mb.setBounds(0,0,1550,30);
        image.add(mb);
        
        JMenu traffic = new JMenu("TRAFFIC MANAGEMENT");
        traffic.setForeground(Color.BLACK);
        mb.add(traffic);
        
        JMenuItem information = new JMenuItem("INFORMATION");
        information.addActionListener(this);
        traffic.add(information);
        
        /*JMenuItem route = new JMenuItem("ROUTE MANAGEMENT");
        route.addActionListener(this);
        traffic.add(route);
        
        JMenuItem vehicles = new JMenuItem("TOWED VEHICLES");
        vehicles.addActionListener(this);
        traffic.add(vehicles);
       
        JMenu police = new JMenu("TRAFFIC POLICE");
        police.setForeground(Color.BLACK);
        mb.add(police);
        
        JMenuItem challan = new JMenuItem("CHALLAN");
        challan.addActionListener(this);
        police.add(challan);*/
        
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if(ae.getActionCommand().equals("CHALLAN")){
            new Challan();
        }
        if(ae.getActionCommand().equals("ROUTE MANAGEMENT")){
            new RoadT();
        }
        if(ae.getActionCommand().equals("TOWED VEHICLES")){
            new ToedVehicles();
        }
        else if(ae.getActionCommand().equals("INFORMATION")){
            new Information2();
        }
    }
    
    
public static void main(String[] args){
new Dasboard2();
}
}

