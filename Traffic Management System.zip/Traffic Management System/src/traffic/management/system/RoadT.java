package traffic.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class RoadT extends JFrame implements ActionListener{
    
    JRadioButton routouse,rdrepair;
    JRadioButton ravailable,rnotavailable;
    JButton add;
    JComboBox cbltype;
    JTextField tfname,tfblock, tfaltroad;
    RoadT(){
        
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        
        JLabel heading = new JLabel("ROUTE MANAGEMENT");
        heading.setFont(new Font("Tahoma", Font.BOLD, 20));
        heading.setBounds(120,20,300,20);
        add(heading);
        
        JLabel lblname = new JLabel("ROAD NAME");
        lblname.setBounds(20,100,200,30);
        lblname.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblname.setForeground(Color.BLACK);
        add(lblname);
        
        tfname = new JTextField();
        tfname.setBounds(300,100,150,30);
        add(tfname);
        
        
        
        JLabel lblblock = new JLabel("CAUSE OF BLOCKAGE");
        lblblock.setBounds(20,150,200,30);
        lblblock.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblblock.setForeground(Color.BLACK);
        add(lblblock);
        
        tfblock = new JTextField();
        tfblock.setBounds(300,150,150,30);
        add(tfblock);
        
        JLabel lblstatus = new JLabel("STATUS");
        lblstatus.setBounds(20,200,200,30);
        lblstatus.setFont(new Font("Raleway",Font.PLAIN,19));
        add(lblstatus);
        
        routouse = new JRadioButton("Out of Use");
        routouse.setBackground(Color.WHITE);
        routouse.setBounds(300,200,90,19);
        add(routouse);
        
        rdrepair = new JRadioButton("Under Repair");
        rdrepair.setBackground(Color.WHITE);
        rdrepair.setBounds(390,200,110,19);
        add(rdrepair);
        
        ButtonGroup bg = new ButtonGroup();
        bg.add(routouse);
        bg.add(rdrepair);
        
        
        JLabel lblaltroute = new JLabel("ALTERNATE ROUTE");
        lblaltroute.setBounds(20,250,200,30);
        lblaltroute.setFont(new Font("Raleway",Font.PLAIN,19));
        add(lblaltroute);
        
        ravailable = new JRadioButton("Available");
        ravailable.setBackground(Color.WHITE);
        ravailable.setBounds(300,250,80,19);
        add(ravailable);
        
        rnotavailable = new JRadioButton("Not Available");
        rnotavailable.setBackground(Color.WHITE);
        rnotavailable.setBounds(380,250,100,19);
        add(rnotavailable);
        
        ButtonGroup bgg = new ButtonGroup();
        bgg.add(ravailable);
        bgg.add(rnotavailable);
       
      
        
        JLabel lblaltroad = new JLabel("ALTERNATE ROAD NAME");
        lblaltroad.setBounds(20,300,230,19);
        lblaltroad.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblaltroad.setForeground(Color.BLACK);
        add(lblaltroad);
        
        tfaltroad = new JTextField();
        tfaltroad.setBounds(300,300,150,30);
        add(tfaltroad);
        
        JLabel lblnlane = new JLabel("LANE");
        lblnlane.setBounds(20,350,150,19);
        lblnlane.setFont(new Font("Tahoma", Font.PLAIN, 19));
        lblnlane.setForeground(Color.BLACK);
        add(lblnlane);
        
       String str[] = { "1 Lane", "2 Lane", "3 Lane", "4 Lane"};
      cbltype = new JComboBox(str);
      cbltype.setBounds(300,350,150,30);
      cbltype.setBackground(Color.WHITE);
       add(cbltype);
       
       add = new JButton("ADD");
       add.setBackground(Color.BLACK);
       add.setForeground(Color.WHITE);
       add.setBounds(135,410,150,30);
       add.addActionListener(this);
       add(add);
        
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/thirteen.jpg"));
       Image i2 = i1.getImage().getScaledInstance(250, 400, Image.SCALE_DEFAULT);
       ImageIcon i3 = new ImageIcon(i2);
       JLabel image = new JLabel(i3);
       image.setBounds(500,50,250,400);
       add(image);
        
        setBounds(350,350,800,550);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        
        //JComboBox comboshift;
    String name = tfname.getText();
    String blockage = tfblock.getText();
    String alternateroad = tfaltroad.getText();
    //JRadioButton routouse,rdrepair;
    //JRadioButton ravailable,rnotavailable;
    //JComboBox cbltype
    
    
    String status = null;
    //JRadioButton rmale,rfemale;
    //JButton add, back;
        if(routouse.isSelected()){
            status="Out of Use";
            
        } else if(rdrepair.isSelected()){
            status="Under Repair";
        }
        String lanetype = (String) cbltype.getSelectedItem();
        
        
        String alternateroute = null;
        if(ravailable.isSelected()){
            status="Available";
            
        } else if(rnotavailable.isSelected()){
            status="Not Available";
        }
        /*if(name.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid name!");
        return;
        }
        if(number.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid number!");
        return;
        }
        if(designation.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a designation!");
        return;
        }
        if(place.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid place!");
        return;
        }*/
        
        try {
            Conn conn = new Conn();
            
            String query = "insert into roadmgmnt values('"+name+"','"+blockage+"','"+status+"','"+alternateroute+"','"+alternateroad+"','"+lanetype+"')";
            conn.s.executeUpdate(query);
         
            
            JOptionPane.showMessageDialog(null, "Route's information added Successfully!");
            setVisible(false);
        
        } catch(Exception e) {
            e.printStackTrace();
        }
        setVisible(false);
    }
       
    public static void main(String[] args){
        new RoadT();
    }
}
