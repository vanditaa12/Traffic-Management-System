package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.*;

public class cinfo extends JFrame implements ActionListener{
    JTable table;
    JButton back;
    cinfo(){
         
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/seventeen.jpg"));
        Image i2 = i1.getImage().getScaledInstance(400,500, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(560,20,510,510);
        add(image);
        
        JLabel l1 = new JLabel("Name");
        l1.setBounds(0,10,180,20);
        add(l1);
        
        JLabel l2 = new JLabel("Phone");
        l2.setBounds(80,10,80,20);
        add(l2);
        
        JLabel l3 = new JLabel("V Number");
        l3.setBounds(160,10,80,20);
        add(l3);
        
        JLabel l4 = new JLabel("Vehicle");
        l4.setBounds(250,10,80,20);
        add(l4);
        
        JLabel l5 = new JLabel("Receipt");
        l5.setBounds(330,10,90,20);
        add(l5);
        
        JLabel l6 = new JLabel("Amount");
        l6.setBounds(410,10,80,20);
        add(l6);
        
        JLabel l7 = new JLabel("Mode");
        l7.setBounds(490,10,80,20);
        add(l7);
        
      
        
        table = new JTable();
        table.setBounds(0,40,580,400);
        add(table);
        
        try{
            Conn c =  new Conn();
            ResultSet rs = c.s.executeQuery("select * from tpolicec");
            table.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch(Exception e){
            e.printStackTrace();
        }
        
        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(200,500,120,30);
        add(back);
        
        
        setBounds(300,200,1050,600);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Information();
    }
    
    public static void main(String[] args){
        new cinfo();
    }
}
