package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class ToedVehicles extends JFrame implements ActionListener{
    
    JButton add;
    JTextField tfowner, tfplate, tfdate;
    JComboBox seizecombo, cbvtype;
   
    
    
    ToedVehicles(){
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
       
        
        JLabel heading = new JLabel("Towed Vehicles");
        heading.setFont(new Font("Tahoma", Font.BOLD, 20));
        heading.setBounds(150,20,200,20);
        add(heading);
        
         JLabel lblowner = new JLabel("Owner's Name");
        lblowner.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblowner.setBounds(60,80,200,30);
        add(lblowner);
        
        tfowner = new JTextField();
        tfowner.setBounds(220,80,230,30);
        add(tfowner);
        
        /*JLabel lblnoplate = new JLabel("Vehicle's Number");
        lblnoplate.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblnoplate.setBounds(100,130,200,30);
        add(lblnoplate);*/
        
        JLabel lblplate = new JLabel("Vehicle's Number");
        lblplate.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblplate.setBounds(60,130,200,30);
        add(lblplate);
        
        tfplate = new JTextField();
        tfplate.setBounds(220,130,230,30);
        add(tfplate);
        
        JLabel lbldate = new JLabel("Date");
        lbldate.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lbldate.setBounds(60,180,200,30);
        add(lbldate);
        
        tfdate = new JTextField();
        tfdate.setBounds(220,180,230,30);
        add(tfdate);
       
        
        JLabel lbltype = new JLabel("Vehicle Type");
       lbltype.setBounds(60,230,200,30);
       lbltype.setFont(new Font("Tahoma", Font.PLAIN, 17));
       add(lbltype);
       
       String str[] = { "Bike", "Scooty", "Car", "Auto Rickshaw", "E Rickshaw", "Van", "Pick-Up Van", "Traveller", "Bus", "Truck" };
       cbvtype = new JComboBox(str);
       cbvtype.setBounds(220,230,230,30);
       cbvtype.setBackground(Color.WHITE);
       add(cbvtype);
       
       JLabel lblseize = new JLabel("Seized or Released");
       lblseize.setBounds(60,280,210,30);
       lblseize.setFont(new Font("Tahoma", Font.PLAIN, 17));
       add(lblseize);
       
       String seizeOptions[] = { "Seiezed", "Released" };
       seizecombo = new JComboBox(seizeOptions);
       seizecombo.setBounds(220,280,230,30);
       seizecombo.setBackground(Color.WHITE);
       add(seizecombo);
       
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/fourth.jpg"));
       Image i2 = i1.getImage().getScaledInstance(250, 400, Image.SCALE_DEFAULT);
       ImageIcon i3 = new ImageIcon(i2);
       JLabel image = new JLabel(i3);
       image.setBounds(570,20,250,400);
       add(image);
       
       
       add = new JButton("ADD");
       add.setBackground(Color.BLACK);
       add.setForeground(Color.WHITE);
       add.setBounds(135,350,150,30);
       add.addActionListener(this);
       add(add);
       
       /*cancel = new JButton("CANCEL");
       cancel.setBackground(Color.BLACK);
       cancel.setForeground(Color.WHITE);
       cancel.setBounds(305,350,150,30);
       cancel.addActionListener(this);
       add(cancel);*/
       
       
       setBounds(330,500,940,470);
       setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
    //if (ae.getSource() == add) {
        String ownername = tfowner.getText();
        String vehiclenumber = tfplate.getText();
        String date = tfdate.getText();
        String vtype = (String) cbvtype.getSelectedItem();
        String seize = (String) seizecombo.getSelectedItem();
        
        /*if(ownername.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid name!");
        return;
        }
        
        if(vehiclenumber.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid number!");
        return;
        }
        
        if(date.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid date!");
        return;
        }*/
        
         if(ownername.equals("")){
            JOptionPane.showMessageDialog(null,"Please add a valid name!");
        return;
        }
        
        
        try {
            Conn conn = new Conn();
            String str = "insert into towvehicles values('"+ownername+"', '"+vehiclenumber+"', '"+date+"','"+vtype+"','"+seize+"')";        
            conn.s.executeUpdate(str);
        
            JOptionPane.showMessageDialog(null, "Details of Towed Vehicle added successfully!");
            setVisible(false);
            
        } 
        
        catch(Exception e){
            e.printStackTrace();
        }
        setVisible(false);
        
    }
    

    public static void main(String[] args){
        new ToedVehicles();
}
}

