package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Information2 extends JFrame implements ActionListener{

	
	public Information2(){
		
                getContentPane().setBackground(Color.WHITE);
                setLayout(null);
                setBackground(Color.LIGHT_GRAY);
                
                /*contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);*/
                
                ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("Icons/eleven.jpg"));
                Image i3 = i1.getImage().getScaledInstance(450, 500,Image.SCALE_DEFAULT);
                ImageIcon i2 = new ImageIcon(i3);
                JLabel l1 = new JLabel(i2);
                l1.setBounds(270,30,500,470);
                add(l1);
                
                
                JButton vehicles = new JButton("Add Route Diversions");
                vehicles.setBounds(10,100,250,30);
                vehicles.setBackground(Color.BLACK);
                vehicles.setForeground(Color.WHITE);
                vehicles.addActionListener(this);
                add(vehicles);
                
                
                JButton vehiclei= new JButton("Person on Duty Info");
                vehiclei.setBounds(10,140,250,30);
                vehiclei.setBackground(Color.BLACK);
                vehiclei.setForeground(Color.WHITE);
                vehiclei.addActionListener(this);
                add(vehiclei);
                
                JButton challan = new JButton("Challan Info");
                challan.setBounds(10,180,250,30);
                challan.setBackground(Color.BLACK);
                challan.setForeground(Color.WHITE);
                challan.addActionListener(this);
                add(challan);
                
                
                JButton routei = new JButton("Route Diversions by Traffic Police");
                routei.setBounds(10,220,250,30);
                routei.setBackground(Color.BLACK);
                routei.setForeground(Color.WHITE);
                routei.addActionListener(this);
                add(routei);
                
     
                JButton routel = new JButton("Route Diversions by Localites");
                routel.setBounds(10,260,250,30);
                routel.setBackground(Color.BLACK);
                routel.setForeground(Color.WHITE);
                routel.addActionListener(this);
                add(routel);
                
                JButton tvehicle = new JButton("Towed Vehicles Info");
                tvehicle.setBounds(10,300,250,30);
                tvehicle.setBackground(Color.BLACK);
                tvehicle.setForeground(Color.WHITE);
                tvehicle.addActionListener(this);
                add(tvehicle);
       
                JButton log = new JButton("Logout");
                log.setBounds(10,340,250,30);
                log.setBackground(Color.BLACK);
                log.setForeground(Color.WHITE);
                log.addActionListener(this);
                add(log);
                
                setBounds(200, 180, 800, 570);
		setVisible(true);
        }
        
         public void actionPerformed(ActionEvent ae) {
        if(ae.getActionCommand().equals("Add Route Diversions")){
            new route2();
        }
        if(ae.getActionCommand().equals("Route Diversions by Traffic Police")){
            new Route();
        }
        if(ae.getActionCommand().equals("Towed Vehicles Info")){
            new tvinfo();
        }
        if(ae.getActionCommand().equals("Person on Duty Info")){
            new podinfo();
        }
        if(ae.getActionCommand().equals("Route Diversions by Localites")){
            new routel();
        }
        if(ae.getActionCommand().equals("Challan Info")){
            new cinfo();
        }
        if(ae.getActionCommand().equals("Vehicle Info")){
            new Vinfo();
        }
        if(ae.getActionCommand().equals("Logout")){
        setVisible(false);
//        new Dashboard();
        
        }
        /*else if(ae.getActionCommand().equals("INFORMATION")){
            new Information();
        }
    
        */
         }    
        public static void main(String[] args) {
		new Information2();
	}
}
