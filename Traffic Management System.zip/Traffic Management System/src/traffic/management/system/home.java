package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class home extends JFrame implements ActionListener{
    
    home(){
        setBounds(0,0,1550,1000);
        
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/hundred.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1550,1000, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,1550,1000);
        add(image);
        
        JLabel text = new JLabel("TRAFFIC MANAGEMENT SYSTEM");
        text.setBounds(120,60,1000,70);
        text.setFont(new Font("Tahoma",Font.PLAIN,46));
        text.setForeground(Color.WHITE);
        image.add(text);
        
        JButton adminl = new JButton("Login As Admin");
                adminl.setBounds(115,420,290,45);
                adminl.setBackground(Color.LIGHT_GRAY);
                adminl.setForeground(Color.BLACK);
                adminl.addActionListener(this);
                add(adminl);
                
                JButton userl = new JButton("Visit As User");
                userl.setBounds(115,490,290,45);
                userl.setBackground(Color.LIGHT_GRAY);
                userl.setForeground(Color.BLACK);
                userl.addActionListener(this);
                add(userl);
                
                
                
                
       
        
        
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if(ae.getActionCommand().equals("Login As Admin")){
            new Login();
        }
        else if(ae.getActionCommand().equals("Visit As User")){
            new log();
        }
        /*if(ae.getActionCommand().equals("TOWED VEHICLES")){
            new ToedVehicles();
        }
        else if(ae.getActionCommand().equals("INFORMATION")){
            new Information();
        }*/
    }

    
    
public static void main(String[] args){
new home();
}
}
