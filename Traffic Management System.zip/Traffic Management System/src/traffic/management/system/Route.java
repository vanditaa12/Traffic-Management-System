
package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.*;

public class Route extends JFrame implements ActionListener{
    JTable table;
    JButton back;
    Route(){
         
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/fourteen.jpg"));
        Image i2 = i1.getImage().getScaledInstance(600,600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(500,20,510,510);
        add(image);
        
        JLabel l1 = new JLabel("Road Name");
        l1.setBounds(0,10,80,20);
        add(l1);
        
        JLabel l2 = new JLabel("Block Cause");
        l2.setBounds(90,10,80,20);
        add(l2);
        
        JLabel l3 = new JLabel("Alt Route");
        l3.setBounds(180,10,80,20);
        add(l3);
        
        JLabel l4 = new JLabel("Status");
        l4.setBounds(270,10,80,20);
        add(l4);
        
        JLabel l5 = new JLabel("Alt R Name");
        l5.setBounds(350,10,90,20);
        add(l5);
        
        JLabel l6 = new JLabel("Lane");
        l6.setBounds(450,10,80,20);
        add(l6);
        
        table = new JTable();
        table.setBounds(0,40,500,400);
        add(table);
        
        try{
            Conn c =  new Conn();
            ResultSet rs = c.s.executeQuery("select * from roadmgmnt");
            table.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch(Exception e){
            e.printStackTrace();
        }
        
        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(200,500,120,30);
        add(back);
        
        
        setBounds(300,200,1050,600);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Information();
    }
    
    public static void main(String[] args){
        new Route();
    }
}
