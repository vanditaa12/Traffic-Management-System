package traffic.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Information extends JFrame implements ActionListener{

	
	public Information(){
		
                getContentPane().setBackground(Color.WHITE);
                setLayout(null);
                setBackground(Color.LIGHT_GRAY);
                
                /*contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);*/
                
                ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("Icons/eleven.jpg"));
                Image i3 = i1.getImage().getScaledInstance(500, 500,Image.SCALE_DEFAULT);
                ImageIcon i2 = new ImageIcon(i3);
                JLabel l1 = new JLabel(i2);
                l1.setBounds(250,30,500,470);
                add(l1);
                
                
                JButton vehicles = new JButton("Vehicles");
                vehicles.setBounds(10,100,200,30);
                vehicles.setBackground(Color.BLACK);
                vehicles.setForeground(Color.WHITE);
                vehicles.addActionListener(this);
                add(vehicles);
                
                
                JButton vehiclei= new JButton("Person on Duty Info");
                vehiclei.setBounds(10,140,200,30);
                vehiclei.setBackground(Color.BLACK);
                vehiclei.setForeground(Color.WHITE);
                vehiclei.addActionListener(this);
                add(vehiclei);
                
                JButton challan = new JButton("Challan");
                challan.setBounds(10,180,200,30);
                challan.setBackground(Color.BLACK);
                challan.setForeground(Color.WHITE);
                challan.addActionListener(this);
                add(challan);
                
                JButton addperson = new JButton("Person On Duty");
                addperson.setBounds(10,220,200,30);
                addperson.setBackground(Color.BLACK);
                addperson.addActionListener(this);
                addperson.setForeground(Color.WHITE);
                add(addperson);
                
                JButton routei = new JButton("Route");
                routei.setBounds(10,260,200,30);
                routei.setBackground(Color.BLACK);
                routei.setForeground(Color.WHITE);
                routei.addActionListener(this);
                add(routei);
                
     
                
                JButton tvehicle = new JButton("Towed Vehicles");
                tvehicle.setBounds(10,300,200,30);
                tvehicle.setBackground(Color.BLACK);
                tvehicle.setForeground(Color.WHITE);
                tvehicle.addActionListener(this);
                add(tvehicle);
                
                JButton tvehicleinfo = new JButton("Vehicle Info");
                tvehicleinfo.setBounds(10,340,200,30);
                tvehicleinfo.setBackground(Color.BLACK);
                tvehicleinfo.setForeground(Color.WHITE);
                tvehicleinfo.addActionListener(this);
                add(tvehicleinfo);

                
                JButton log = new JButton("Logout");
                log.setBounds(10,380,200,30);
                log.setBackground(Color.BLACK);
                log.setForeground(Color.WHITE);
                log.addActionListener(this);
                add(log);
                
                setBounds(300, 200, 800, 570);
		setVisible(true);
        }
        
         public void actionPerformed(ActionEvent ae) {
        if(ae.getActionCommand().equals("Person On Duty")){
            new AddPerson();
        }
        if(ae.getActionCommand().equals("Route")){
            new Route();
        }
        if(ae.getActionCommand().equals("Towed Vehicles")){
            new tvinfo();
        }
        if(ae.getActionCommand().equals("Person on Duty Info")){
            new podinfo();
        }
        if(ae.getActionCommand().equals("Vehicles")){
            new Vehicle();
        }
        if(ae.getActionCommand().equals("Challan")){
            new cinfo();
        }
        if(ae.getActionCommand().equals("Vehicle Info")){
            new Vinfo();
        }
        if(ae.getActionCommand().equals("Logout")){
        setVisible(false);
//        new Dashboard();
        
        }
        /*else if(ae.getActionCommand().equals("INFORMATION")){
            new Information();
        }
    
        */
         }    
        public static void main(String[] args) {
		new Information();
	}
}